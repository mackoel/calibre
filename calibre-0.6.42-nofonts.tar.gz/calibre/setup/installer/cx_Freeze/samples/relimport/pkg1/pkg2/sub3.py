print "importing pkg1.pkg2.sub3"
from . import sub5
from .. import sub6
