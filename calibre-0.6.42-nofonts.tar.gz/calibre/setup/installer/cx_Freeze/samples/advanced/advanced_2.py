import sys

print "Hello from cx_Freeze Advanced #2"
print

module = __import__("testfreeze_2")

