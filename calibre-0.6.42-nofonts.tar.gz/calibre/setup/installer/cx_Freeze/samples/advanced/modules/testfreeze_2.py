print "Test freeze module #2"
