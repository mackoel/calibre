#pragma once

int run(const char **ENV_VARS, const char **ENV_VAR_VALS, char *PROGRAM,
        const char *MODULE, const char *FUNCTION, const char *PYVER,
        int argc, const char **argv, const char **envp);
