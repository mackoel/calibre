#!/usr/bin/env  python
__license__   = 'GPL v3'
__copyright__ = '2008, John Schember john@nachtimwald.com'
__docformat__ = 'restructuredtext en'

'''
Used for txt output
'''

