#!/usr/bin/env  python
__license__   = 'GPL v3'
__copyright__ = '2008, Kovid Goyal kovid@kovidgoyal.net'
__docformat__ = 'restructuredtext en'

'''
Convert CBR/CBZ files to LRF.
'''

import sys

def main(args=sys.argv):
    return 0

if __name__ == '__main__':
    sys.exit(main())