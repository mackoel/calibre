# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/device_drivers/configwidget.ui'
#
# Created: Thu Dec 31 16:24:25 2009
#      by: PyQt4 UI code generator 4.6.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_ConfigWidget(object):
    def setupUi(self, ConfigWidget):
        ConfigWidget.setObjectName("ConfigWidget")
        ConfigWidget.resize(442, 332)
        self.gridLayout = QtGui.QGridLayout(ConfigWidget)
        self.gridLayout.setObjectName("gridLayout")
        self.groupBox = QtGui.QGroupBox(ConfigWidget)
        self.groupBox.setObjectName("groupBox")
        self.verticalLayout_7 = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout_7.setObjectName("verticalLayout_7")
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.columns = QtGui.QListWidget(self.groupBox)
        self.columns.setAlternatingRowColors(True)
        self.columns.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.columns.setObjectName("columns")
        self.horizontalLayout_3.addWidget(self.columns)
        self.verticalLayout_3 = QtGui.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.column_up = QtGui.QToolButton(self.groupBox)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("arrow-up.svg")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.column_up.setIcon(icon)
        self.column_up.setObjectName("column_up")
        self.verticalLayout_3.addWidget(self.column_up)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem)
        self.column_down = QtGui.QToolButton(self.groupBox)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(I("arrow-down.svg")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.column_down.setIcon(icon1)
        self.column_down.setObjectName("column_down")
        self.verticalLayout_3.addWidget(self.column_down)
        self.horizontalLayout_3.addLayout(self.verticalLayout_3)
        self.verticalLayout_7.addLayout(self.horizontalLayout_3)
        self.gridLayout.addWidget(self.groupBox, 0, 0, 1, 1)
        self.opt_read_metadata = QtGui.QCheckBox(ConfigWidget)
        self.opt_read_metadata.setObjectName("opt_read_metadata")
        self.gridLayout.addWidget(self.opt_read_metadata, 1, 0, 1, 1)
        self.opt_use_subdirs = QtGui.QCheckBox(ConfigWidget)
        self.opt_use_subdirs.setObjectName("opt_use_subdirs")
        self.gridLayout.addWidget(self.opt_use_subdirs, 2, 0, 1, 1)
        self.extra_customization_label = QtGui.QLabel(ConfigWidget)
        self.extra_customization_label.setWordWrap(True)
        self.extra_customization_label.setObjectName("extra_customization_label")
        self.gridLayout.addWidget(self.extra_customization_label, 5, 0, 1, 1)
        self.opt_extra_customization = QtGui.QLineEdit(ConfigWidget)
        self.opt_extra_customization.setObjectName("opt_extra_customization")
        self.gridLayout.addWidget(self.opt_extra_customization, 6, 0, 1, 1)
        self.label = QtGui.QLabel(ConfigWidget)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 3, 0, 1, 1)
        self.opt_save_template = QtGui.QLineEdit(ConfigWidget)
        self.opt_save_template.setObjectName("opt_save_template")
        self.gridLayout.addWidget(self.opt_save_template, 4, 0, 1, 1)
        self.extra_customization_label.setBuddy(self.opt_extra_customization)
        self.label.setBuddy(self.opt_save_template)

        self.retranslateUi(ConfigWidget)
        QtCore.QMetaObject.connectSlotsByName(ConfigWidget)

    def retranslateUi(self, ConfigWidget):
        ConfigWidget.setWindowTitle(_("Form"))
        self.groupBox.setTitle(_("Select available formats and their order for this device"))
        self.column_up.setText(_("..."))
        self.column_down.setText(_("..."))
        self.opt_read_metadata.setText(_("Read metadata from files on device"))
        self.opt_use_subdirs.setText(_("Use sub directories"))
        self.extra_customization_label.setText(_("Extra customization"))
        self.label.setText(_("Save &template:"))


