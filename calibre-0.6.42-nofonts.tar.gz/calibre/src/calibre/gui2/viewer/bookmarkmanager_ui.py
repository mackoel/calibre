# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/viewer/bookmarkmanager.ui'
#
# Created: Fri Sep 25 13:36:51 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_BookmarkManager(object):
    def setupUi(self, BookmarkManager):
        BookmarkManager.setObjectName("BookmarkManager")
        BookmarkManager.resize(451, 363)
        self.gridLayout = QtGui.QGridLayout(BookmarkManager)
        self.gridLayout.setObjectName("gridLayout")
        self.groupBox = QtGui.QGroupBox(BookmarkManager)
        self.groupBox.setObjectName("groupBox")
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName("verticalLayout")
        self.button_edit = QtGui.QPushButton(self.groupBox)
        self.button_edit.setObjectName("button_edit")
        self.verticalLayout.addWidget(self.button_edit)
        self.button_delete = QtGui.QPushButton(self.groupBox)
        self.button_delete.setObjectName("button_delete")
        self.verticalLayout.addWidget(self.button_delete)
        self.button_revert = QtGui.QPushButton(self.groupBox)
        self.button_revert.setObjectName("button_revert")
        self.verticalLayout.addWidget(self.button_revert)
        self.button_export = QtGui.QPushButton(self.groupBox)
        self.button_export.setObjectName("button_export")
        self.verticalLayout.addWidget(self.button_export)
        self.button_import = QtGui.QPushButton(self.groupBox)
        self.button_import.setObjectName("button_import")
        self.verticalLayout.addWidget(self.button_import)
        self.gridLayout.addWidget(self.groupBox, 0, 0, 1, 1)
        self.bookmarks_table = QtGui.QTableView(BookmarkManager)
        self.bookmarks_table.setProperty("showDropIndicator", QtCore.QVariant(False))
        self.bookmarks_table.setAlternatingRowColors(True)
        self.bookmarks_table.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.bookmarks_table.setSortingEnabled(False)
        self.bookmarks_table.setObjectName("bookmarks_table")
        self.gridLayout.addWidget(self.bookmarks_table, 0, 1, 1, 1)
        self.buttonBox = QtGui.QDialogButtonBox(BookmarkManager)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout.addWidget(self.buttonBox, 1, 0, 1, 2)

        self.retranslateUi(BookmarkManager)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("accepted()"), BookmarkManager.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("rejected()"), BookmarkManager.reject)
        QtCore.QMetaObject.connectSlotsByName(BookmarkManager)

    def retranslateUi(self, BookmarkManager):
        BookmarkManager.setWindowTitle(_("Bookmark Manager"))
        self.groupBox.setTitle(_("Actions"))
        self.button_edit.setText(_("Edit"))
        self.button_delete.setText(_("Delete"))
        self.button_revert.setText(_("Reset"))
        self.button_export.setText(_("Export"))
        self.button_import.setText(_("Import"))

