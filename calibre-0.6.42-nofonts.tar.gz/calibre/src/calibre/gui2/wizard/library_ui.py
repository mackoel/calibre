# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/wizard/library.ui'
#
# Created: Mon Oct 12 12:57:45 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_WizardPage(object):
    def setupUi(self, WizardPage):
        WizardPage.setObjectName("WizardPage")
        WizardPage.resize(481, 300)
        self.gridLayout = QtGui.QGridLayout(WizardPage)
        self.gridLayout.setObjectName("gridLayout")
        self.label_3 = QtGui.QLabel(WizardPage)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 0, 0, 1, 1)
        self.language = QtGui.QComboBox(WizardPage)
        self.language.setObjectName("language")
        self.gridLayout.addWidget(self.language, 0, 1, 1, 2)
        self.label = QtGui.QLabel(WizardPage)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 2, 0, 1, 3)
        self.location = QtGui.QLineEdit(WizardPage)
        self.location.setReadOnly(True)
        self.location.setObjectName("location")
        self.gridLayout.addWidget(self.location, 3, 0, 1, 2)
        self.button_change = QtGui.QPushButton(WizardPage)
        self.button_change.setObjectName("button_change")
        self.gridLayout.addWidget(self.button_change, 3, 2, 1, 1)
        self.label_2 = QtGui.QLabel(WizardPage)
        self.label_2.setWordWrap(True)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 4, 0, 1, 3)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 1, 0, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem1, 5, 0, 1, 1)
        self.label_3.setBuddy(self.language)

        self.retranslateUi(WizardPage)
        QtCore.QMetaObject.connectSlotsByName(WizardPage)

    def retranslateUi(self, WizardPage):
        WizardPage.setWindowTitle(_("WizardPage"))
        WizardPage.setTitle(_("Welcome to calibre"))
        WizardPage.setSubTitle(_("The one stop solution to all your e-book needs."))
        self.label_3.setText(_("Choose your &language:"))
        self.label.setText(_("Choose a location for your books. When you add books to calibre, they will be copied here:"))
        self.button_change.setText(_("&Change"))
        self.label_2.setText(_("If you have an existing calibre library, it will be copied to the new location. If a calibre library already exists at the new location, calibre will switch to using it."))

