# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/wizard/device.ui'
#
# Created: Fri Sep 25 13:36:51 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_WizardPage(object):
    def setupUi(self, WizardPage):
        WizardPage.setObjectName("WizardPage")
        WizardPage.resize(400, 300)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("wizard.svg")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        WizardPage.setWindowIcon(icon)
        self.gridLayout = QtGui.QGridLayout(WizardPage)
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtGui.QLabel(WizardPage)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 2)
        self.groupBox = QtGui.QGroupBox(WizardPage)
        self.groupBox.setObjectName("groupBox")
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName("verticalLayout")
        self.manufacturer_view = QtGui.QListView(self.groupBox)
        self.manufacturer_view.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.manufacturer_view.setObjectName("manufacturer_view")
        self.verticalLayout.addWidget(self.manufacturer_view)
        self.gridLayout.addWidget(self.groupBox, 1, 0, 1, 1)
        self.groupBox_2 = QtGui.QGroupBox(WizardPage)
        self.groupBox_2.setObjectName("groupBox_2")
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox_2)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.device_view = QtGui.QListView(self.groupBox_2)
        self.device_view.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.device_view.setObjectName("device_view")
        self.verticalLayout_2.addWidget(self.device_view)
        self.gridLayout.addWidget(self.groupBox_2, 1, 1, 1, 1)

        self.retranslateUi(WizardPage)
        QtCore.QMetaObject.connectSlotsByName(WizardPage)

    def retranslateUi(self, WizardPage):
        WizardPage.setWindowTitle(_("Welcome to calibre"))
        WizardPage.setTitle(_("Welcome to calibre"))
        WizardPage.setSubTitle(_("The one stop solution to all your e-book needs."))
        self.label.setText(_("Choose your book reader. This will set the conversion options to produce books optimized for your device."))
        self.groupBox.setTitle(_("&Manufacturers"))
        self.groupBox_2.setTitle(_("&Devices"))


