# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/convert/epub_output.ui'
#
# Created: Fri Sep 25 13:36:50 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)
        self.gridLayout = QtGui.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.opt_dont_split_on_page_breaks = QtGui.QCheckBox(Form)
        self.opt_dont_split_on_page_breaks.setObjectName("opt_dont_split_on_page_breaks")
        self.gridLayout.addWidget(self.opt_dont_split_on_page_breaks, 0, 0, 1, 2)
        self.label = QtGui.QLabel(Form)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 2, 0, 1, 1)
        self.opt_flow_size = QtGui.QSpinBox(Form)
        self.opt_flow_size.setMinimum(100)
        self.opt_flow_size.setMaximum(1000000)
        self.opt_flow_size.setSingleStep(20)
        self.opt_flow_size.setObjectName("opt_flow_size")
        self.gridLayout.addWidget(self.opt_flow_size, 2, 1, 1, 1)
        spacerItem = QtGui.QSpacerItem(20, 262, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 3, 0, 1, 1)
        self.opt_no_default_epub_cover = QtGui.QCheckBox(Form)
        self.opt_no_default_epub_cover.setObjectName("opt_no_default_epub_cover")
        self.gridLayout.addWidget(self.opt_no_default_epub_cover, 1, 0, 1, 1)
        self.label.setBuddy(self.opt_flow_size)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_("Form"))
        self.opt_dont_split_on_page_breaks.setText(_("Do not &split on page breaks"))
        self.label.setText(_("Split files &larger than:"))
        self.opt_flow_size.setSuffix(_(" KB"))
        self.opt_no_default_epub_cover.setText(_("No default &cover"))

