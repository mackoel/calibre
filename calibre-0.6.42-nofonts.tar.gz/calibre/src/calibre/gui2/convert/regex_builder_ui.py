# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/convert/regex_builder.ui'
#
# Created: Fri Sep 25 13:36:50 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_RegexBuilder(object):
    def setupUi(self, RegexBuilder):
        RegexBuilder.setObjectName("RegexBuilder")
        RegexBuilder.resize(662, 505)
        self.gridLayout = QtGui.QGridLayout(RegexBuilder)
        self.gridLayout.setObjectName("gridLayout")
        self.groupBox = QtGui.QGroupBox(RegexBuilder)
        self.groupBox.setObjectName("groupBox")
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName("verticalLayout")
        self.preview = QtGui.QPlainTextEdit(self.groupBox)
        self.preview.setUndoRedoEnabled(False)
        self.preview.setReadOnly(True)
        self.preview.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.preview.setObjectName("preview")
        self.verticalLayout.addWidget(self.preview)
        self.gridLayout.addWidget(self.groupBox, 1, 0, 1, 2)
        self.button_box = QtGui.QDialogButtonBox(RegexBuilder)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.gridLayout.addWidget(self.button_box, 2, 1, 1, 1)
        self.label = QtGui.QLabel(RegexBuilder)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.regex = QtGui.QLineEdit(RegexBuilder)
        self.regex.setObjectName("regex")
        self.gridLayout.addWidget(self.regex, 0, 1, 1, 1)

        self.retranslateUi(RegexBuilder)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL("rejected()"), RegexBuilder.reject)
        QtCore.QMetaObject.connectSlotsByName(RegexBuilder)

    def retranslateUi(self, RegexBuilder):
        RegexBuilder.setWindowTitle(_("Regex Builder"))
        self.groupBox.setTitle(_("Preview"))
        self.label.setText(_("Regex:"))

