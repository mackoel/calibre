# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/convert/mobi_output.ui'
#
# Created: Tue Feb  2 14:38:02 2010
#      by: PyQt4 UI code generator 4.7
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(421, 300)
        self.gridLayout = QtGui.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtGui.QLabel(Form)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.opt_toc_title = QtGui.QLineEdit(Form)
        self.opt_toc_title.setObjectName("opt_toc_title")
        self.gridLayout.addWidget(self.opt_toc_title, 1, 1, 1, 1)
        self.opt_rescale_images = QtGui.QCheckBox(Form)
        self.opt_rescale_images.setObjectName("opt_rescale_images")
        self.gridLayout.addWidget(self.opt_rescale_images, 2, 0, 1, 2)
        self.opt_prefer_author_sort = QtGui.QCheckBox(Form)
        self.opt_prefer_author_sort.setObjectName("opt_prefer_author_sort")
        self.gridLayout.addWidget(self.opt_prefer_author_sort, 3, 0, 1, 2)
        self.opt_dont_compress = QtGui.QCheckBox(Form)
        self.opt_dont_compress.setObjectName("opt_dont_compress")
        self.gridLayout.addWidget(self.opt_dont_compress, 4, 0, 1, 1)
        self.opt_no_inline_toc = QtGui.QCheckBox(Form)
        self.opt_no_inline_toc.setObjectName("opt_no_inline_toc")
        self.gridLayout.addWidget(self.opt_no_inline_toc, 0, 0, 1, 1)
        self.groupBox = QtGui.QGroupBox(Form)
        self.groupBox.setObjectName("groupBox")
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.opt_masthead_font = QtGui.QComboBox(self.groupBox)
        self.opt_masthead_font.setObjectName("opt_masthead_font")
        self.verticalLayout.addWidget(self.opt_masthead_font)
        spacerItem = QtGui.QSpacerItem(20, 55, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.gridLayout.addWidget(self.groupBox, 5, 0, 1, 2)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem1, 6, 0, 1, 1)
        self.label.setBuddy(self.opt_toc_title)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_("Form"))
        self.label.setText(_("&Title for Table of Contents:"))
        self.opt_rescale_images.setText(_("Rescale images for &Palm devices"))
        self.opt_prefer_author_sort.setText(_("Use author &sort for author"))
        self.opt_dont_compress.setText(_("Disable compression of the file contents"))
        self.opt_no_inline_toc.setText(_("Do not add Table of Contents to book"))
        self.groupBox.setTitle(_("Kindle options"))
        self.label_2.setText(_("Masthead font:"))

