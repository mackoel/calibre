# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/convert/txt_input.ui'
#
# Created: Sat Jan  9 14:01:12 2010
#      by: PyQt4 UI code generator 4.6.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)
        self.gridLayout = QtGui.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.opt_single_line_paras = QtGui.QCheckBox(Form)
        self.opt_single_line_paras.setObjectName("opt_single_line_paras")
        self.gridLayout.addWidget(self.opt_single_line_paras, 0, 0, 1, 1)
        self.opt_print_formatted_paras = QtGui.QCheckBox(Form)
        self.opt_print_formatted_paras.setObjectName("opt_print_formatted_paras")
        self.gridLayout.addWidget(self.opt_print_formatted_paras, 1, 0, 1, 1)
        self.opt_markdown = QtGui.QCheckBox(Form)
        self.opt_markdown.setObjectName("opt_markdown")
        self.gridLayout.addWidget(self.opt_markdown, 2, 0, 1, 1)
        self.label = QtGui.QLabel(Form)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 3, 0, 1, 1)
        self.opt_markdown_disable_toc = QtGui.QCheckBox(Form)
        self.opt_markdown_disable_toc.setObjectName("opt_markdown_disable_toc")
        self.gridLayout.addWidget(self.opt_markdown_disable_toc, 4, 0, 1, 1)
        spacerItem = QtGui.QSpacerItem(20, 213, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 5, 0, 1, 1)

        self.retranslateUi(Form)
        QtCore.QObject.connect(self.opt_markdown, QtCore.SIGNAL("toggled(bool)"), self.opt_markdown_disable_toc.setEnabled)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_("Form"))
        self.opt_single_line_paras.setText(_("Treat each &line as a paragraph"))
        self.opt_print_formatted_paras.setText(_("Assume print formatting"))
        self.opt_markdown.setText(_("Process using markdown"))
        self.label.setText(_("<p>Markdown is a simple markup language for text files, that allows for advanced formatting. To learn more visit <a href=\"http://daringfireball.net/projects/markdown\">markdown</a>."))
        self.opt_markdown_disable_toc.setText(_("Do not insert Table of Contents into output text when using markdown"))

