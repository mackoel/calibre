# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/convert/txt_output.ui'
#
# Created: Sun Jan  3 18:58:47 2010
#      by: PyQt4 UI code generator 4.6.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)
        self.gridLayout = QtGui.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtGui.QLabel(Form)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.opt_newline = QtGui.QComboBox(Form)
        self.opt_newline.setObjectName("opt_newline")
        self.gridLayout.addWidget(self.opt_newline, 0, 1, 1, 1)
        spacerItem = QtGui.QSpacerItem(20, 246, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 4, 0, 1, 1)
        self.opt_inline_toc = QtGui.QCheckBox(Form)
        self.opt_inline_toc.setObjectName("opt_inline_toc")
        self.gridLayout.addWidget(self.opt_inline_toc, 3, 0, 1, 2)
        self.opt_max_line_length = QtGui.QSpinBox(Form)
        self.opt_max_line_length.setObjectName("opt_max_line_length")
        self.gridLayout.addWidget(self.opt_max_line_length, 1, 1, 1, 1)
        self.label_2 = QtGui.QLabel(Form)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.opt_force_max_line_length = QtGui.QCheckBox(Form)
        self.opt_force_max_line_length.setObjectName("opt_force_max_line_length")
        self.gridLayout.addWidget(self.opt_force_max_line_length, 2, 0, 1, 2)
        self.label.setBuddy(self.opt_newline)
        self.label_2.setBuddy(self.opt_max_line_length)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_("Form"))
        self.label.setText(_("&Line ending style:"))
        self.opt_inline_toc.setText(_("&Inline TOC"))
        self.label_2.setText(_("&Maximum line length:"))
        self.opt_force_max_line_length.setText(_("Force maximum line lenght"))

