# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/convert/structure_detection.ui'
#
# Created: Fri Sep 25 13:36:50 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(657, 479)
        self.gridLayout = QtGui.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.opt_chapter = XPathEdit(Form)
        self.opt_chapter.setObjectName("opt_chapter")
        self.gridLayout.addWidget(self.opt_chapter, 0, 0, 1, 2)
        self.label = QtGui.QLabel(Form)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.opt_chapter_mark = QtGui.QComboBox(Form)
        self.opt_chapter_mark.setObjectName("opt_chapter_mark")
        self.gridLayout.addWidget(self.opt_chapter_mark, 1, 1, 1, 1)
        self.opt_remove_first_image = QtGui.QCheckBox(Form)
        self.opt_remove_first_image.setObjectName("opt_remove_first_image")
        self.gridLayout.addWidget(self.opt_remove_first_image, 2, 0, 1, 1)
        self.opt_insert_metadata = QtGui.QCheckBox(Form)
        self.opt_insert_metadata.setObjectName("opt_insert_metadata")
        self.gridLayout.addWidget(self.opt_insert_metadata, 3, 0, 1, 1)
        self.opt_preprocess_html = QtGui.QCheckBox(Form)
        self.opt_preprocess_html.setObjectName("opt_preprocess_html")
        self.gridLayout.addWidget(self.opt_preprocess_html, 8, 0, 1, 2)
        self.opt_page_breaks_before = XPathEdit(Form)
        self.opt_page_breaks_before.setObjectName("opt_page_breaks_before")
        self.gridLayout.addWidget(self.opt_page_breaks_before, 9, 0, 1, 2)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 10, 0, 1, 1)
        self.opt_remove_footer = QtGui.QCheckBox(Form)
        self.opt_remove_footer.setObjectName("opt_remove_footer")
        self.gridLayout.addWidget(self.opt_remove_footer, 6, 0, 1, 1)
        self.opt_remove_header = QtGui.QCheckBox(Form)
        self.opt_remove_header.setObjectName("opt_remove_header")
        self.gridLayout.addWidget(self.opt_remove_header, 4, 0, 1, 1)
        self.opt_header_regex = RegexEdit(Form)
        self.opt_header_regex.setObjectName("opt_header_regex")
        self.gridLayout.addWidget(self.opt_header_regex, 5, 0, 1, 2)
        self.opt_footer_regex = RegexEdit(Form)
        self.opt_footer_regex.setObjectName("opt_footer_regex")
        self.gridLayout.addWidget(self.opt_footer_regex, 7, 0, 1, 2)
        self.label.setBuddy(self.opt_chapter_mark)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_("Form"))
        self.label.setText(_("Chapter &mark:"))
        self.opt_remove_first_image.setText(_("Remove first &image"))
        self.opt_insert_metadata.setText(_("Insert &metadata as page at start of book"))
        self.opt_preprocess_html.setText(_("&Preprocess input file to possibly improve structure detection"))
        self.opt_remove_footer.setText(_("Remove F&ooter"))
        self.opt_remove_header.setText(_("Remove H&eader"))

from regex_builder import RegexEdit
from calibre.gui2.convert.xpath_wizard import XPathEdit
