# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/dialogs/conversion_error.ui'
#
# Created: Fri Sep 25 13:36:50 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_ConversionErrorDialog(object):
    def setupUi(self, ConversionErrorDialog):
        ConversionErrorDialog.setObjectName("ConversionErrorDialog")
        ConversionErrorDialog.resize(658, 515)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("library.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        ConversionErrorDialog.setWindowIcon(icon)
        self.gridlayout = QtGui.QGridLayout(ConversionErrorDialog)
        self.gridlayout.setObjectName("gridlayout")
        self.label = QtGui.QLabel(ConversionErrorDialog)
        self.label.setPixmap(QtGui.QPixmap(I("dialog_error.svg")))
        self.label.setObjectName("label")
        self.gridlayout.addWidget(self.label, 0, 0, 1, 1)
        self.text = QtGui.QTextBrowser(ConversionErrorDialog)
        self.text.setObjectName("text")
        self.gridlayout.addWidget(self.text, 0, 1, 2, 1)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridlayout.addItem(spacerItem, 1, 0, 1, 1)
        self.buttonBox = QtGui.QDialogButtonBox(ConversionErrorDialog)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.gridlayout.addWidget(self.buttonBox, 2, 1, 1, 1)

        self.retranslateUi(ConversionErrorDialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("accepted()"), ConversionErrorDialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("rejected()"), ConversionErrorDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(ConversionErrorDialog)

    def retranslateUi(self, ConversionErrorDialog):
        ConversionErrorDialog.setWindowTitle(_("ERROR"))


