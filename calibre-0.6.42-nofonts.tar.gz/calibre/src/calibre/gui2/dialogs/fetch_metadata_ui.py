# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/dialogs/fetch_metadata.ui'
#
# Created: Mon Feb  8 22:00:24 2010
#      by: PyQt4 UI code generator 4.7
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_FetchMetadata(object):
    def setupUi(self, FetchMetadata):
        FetchMetadata.setObjectName("FetchMetadata")
        FetchMetadata.setWindowModality(QtCore.Qt.WindowModal)
        FetchMetadata.resize(830, 642)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("metadata.svg")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        FetchMetadata.setWindowIcon(icon)
        self.vboxlayout = QtGui.QVBoxLayout(FetchMetadata)
        self.vboxlayout.setObjectName("vboxlayout")
        self.tlabel = QtGui.QLabel(FetchMetadata)
        self.tlabel.setAlignment(QtCore.Qt.AlignCenter)
        self.tlabel.setWordWrap(True)
        self.tlabel.setOpenExternalLinks(True)
        self.tlabel.setObjectName("tlabel")
        self.vboxlayout.addWidget(self.tlabel)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")
        self.label_2 = QtGui.QLabel(FetchMetadata)
        self.label_2.setObjectName("label_2")
        self.hboxlayout.addWidget(self.label_2)
        self.key = QtGui.QLineEdit(FetchMetadata)
        self.key.setObjectName("key")
        self.hboxlayout.addWidget(self.key)
        self.fetch = QtGui.QPushButton(FetchMetadata)
        self.fetch.setObjectName("fetch")
        self.hboxlayout.addWidget(self.fetch)
        self.vboxlayout.addLayout(self.hboxlayout)
        self.warning = QtGui.QLabel(FetchMetadata)
        self.warning.setWordWrap(True)
        self.warning.setObjectName("warning")
        self.vboxlayout.addWidget(self.warning)
        self.groupBox = QtGui.QGroupBox(FetchMetadata)
        self.groupBox.setObjectName("groupBox")
        self.vboxlayout1 = QtGui.QVBoxLayout(self.groupBox)
        self.vboxlayout1.setObjectName("vboxlayout1")
        self.label_3 = QtGui.QLabel(self.groupBox)
        self.label_3.setObjectName("label_3")
        self.vboxlayout1.addWidget(self.label_3)
        self.matches = QtGui.QTableView(self.groupBox)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        sizePolicy.setHeightForWidth(self.matches.sizePolicy().hasHeightForWidth())
        self.matches.setSizePolicy(sizePolicy)
        self.matches.setAlternatingRowColors(True)
        self.matches.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.matches.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.matches.setObjectName("matches")
        self.vboxlayout1.addWidget(self.matches)
        self.summary = QtGui.QTextBrowser(self.groupBox)
        self.summary.setObjectName("summary")
        self.vboxlayout1.addWidget(self.summary)
        self.vboxlayout.addWidget(self.groupBox)
        self.opt_get_social_metadata = QtGui.QCheckBox(FetchMetadata)
        self.opt_get_social_metadata.setObjectName("opt_get_social_metadata")
        self.vboxlayout.addWidget(self.opt_get_social_metadata)
        self.opt_overwrite_author_title_metadata = QtGui.QCheckBox(FetchMetadata)
        self.opt_overwrite_author_title_metadata.setObjectName("opt_overwrite_author_title_metadata")
        self.vboxlayout.addWidget(self.opt_overwrite_author_title_metadata)
        self.buttonBox = QtGui.QDialogButtonBox(FetchMetadata)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.vboxlayout.addWidget(self.buttonBox)
        self.label_2.setBuddy(self.key)

        self.retranslateUi(FetchMetadata)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("accepted()"), FetchMetadata.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("rejected()"), FetchMetadata.reject)
        QtCore.QMetaObject.connectSlotsByName(FetchMetadata)

    def retranslateUi(self, FetchMetadata):
        FetchMetadata.setWindowTitle(_("Fetch metadata"))
        self.tlabel.setText(_("<p>calibre can find metadata for your books from two locations: <b>Google Books</b> and <b>isbndb.com</b>. <p>To use isbndb.com you must sign up for a <a href=\"http://www.isbndb.com\">free account</a> and enter your access key below."))
        self.label_2.setText(_("&Access Key:"))
        self.fetch.setText(_("Fetch"))
        self.groupBox.setTitle(_("Matches"))
        self.label_3.setText(_("Select the book that most closely matches your copy from the list below"))
        self.opt_get_social_metadata.setText(_("Download &social metadata (tags/rating/etc.) for the selected book"))
        self.opt_overwrite_author_title_metadata.setText(_("Overwrite author and title with author and title of selected book"))


