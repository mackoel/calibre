# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/dialogs/catalog.ui'
#
# Created: Thu Jan 28 19:43:41 2010
#      by: PyQt4 UI code generator 4.7
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(611, 514)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("library.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Dialog.setWindowIcon(icon)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog)
        self.buttonBox.setGeometry(QtCore.QRect(430, 470, 164, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.tabs = QtGui.QTabWidget(Dialog)
        self.tabs.setGeometry(QtCore.QRect(12, 39, 579, 411))
        self.tabs.setObjectName("tabs")
        self.tab = QtGui.QWidget()
        self.tab.setObjectName("tab")
        self.gridLayout_2 = QtGui.QGridLayout(self.tab)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.label = QtGui.QLabel(self.tab)
        self.label.setObjectName("label")
        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)
        self.format = QtGui.QComboBox(self.tab)
        self.format.setObjectName("format")
        self.gridLayout_2.addWidget(self.format, 0, 2, 1, 1)
        self.label_2 = QtGui.QLabel(self.tab)
        self.label_2.setWordWrap(True)
        self.label_2.setObjectName("label_2")
        self.gridLayout_2.addWidget(self.label_2, 1, 0, 1, 1)
        self.title = QtGui.QLineEdit(self.tab)
        self.title.setObjectName("title")
        self.gridLayout_2.addWidget(self.title, 1, 2, 1, 1)
        self.sync = QtGui.QCheckBox(self.tab)
        self.sync.setObjectName("sync")
        self.gridLayout_2.addWidget(self.sync, 3, 0, 1, 1)
        spacerItem = QtGui.QSpacerItem(20, 299, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout_2.addItem(spacerItem, 2, 1, 1, 1)
        self.tabs.addTab(self.tab, "")
        self.count = QtGui.QLabel(Dialog)
        self.count.setGeometry(QtCore.QRect(12, 12, 301, 17))
        font = QtGui.QFont()
        font.setWeight(75)
        font.setBold(True)
        self.count.setFont(font)
        self.count.setObjectName("count")
        self.label.setBuddy(self.format)
        self.label_2.setBuddy(self.title)

        self.retranslateUi(Dialog)
        self.tabs.setCurrentIndex(0)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("accepted()"), Dialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("rejected()"), Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_("Generate catalog"))
        self.label.setText(_("Catalog &format:"))
        self.label_2.setText(_("Catalog &title (existing catalog with the same title will be replaced):"))
        self.sync.setText(_("&Send catalog to device automatically"))
        self.tabs.setTabText(self.tabs.indexOf(self.tab), _("Catalog options"))
        self.count.setText(_("Generate catalog for {0} books"))


