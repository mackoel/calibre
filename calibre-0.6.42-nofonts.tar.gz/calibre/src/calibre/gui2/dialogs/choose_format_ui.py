# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/dialogs/choose_format.ui'
#
# Created: Fri Sep 25 13:36:50 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_ChooseFormatDialog(object):
    def setupUi(self, ChooseFormatDialog):
        ChooseFormatDialog.setObjectName("ChooseFormatDialog")
        ChooseFormatDialog.resize(507, 377)
        icon = QtGui.QIcon()
        icon.addFile(I("mimetypes/unknown.svg"))
        ChooseFormatDialog.setWindowIcon(icon)
        self.vboxlayout = QtGui.QVBoxLayout(ChooseFormatDialog)
        self.vboxlayout.setObjectName("vboxlayout")
        self.msg = QtGui.QLabel(ChooseFormatDialog)
        self.msg.setObjectName("msg")
        self.vboxlayout.addWidget(self.msg)
        self.formats = QtGui.QListWidget(ChooseFormatDialog)
        self.formats.setIconSize(QtCore.QSize(64, 64))
        self.formats.setObjectName("formats")
        self.vboxlayout.addWidget(self.formats)
        self.buttonBox = QtGui.QDialogButtonBox(ChooseFormatDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.vboxlayout.addWidget(self.buttonBox)

        self.retranslateUi(ChooseFormatDialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("accepted()"), ChooseFormatDialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("rejected()"), ChooseFormatDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(ChooseFormatDialog)

    def retranslateUi(self, ChooseFormatDialog):
        ChooseFormatDialog.setWindowTitle(_("Choose Format"))
        self.msg.setText(_("TextLabel"))


