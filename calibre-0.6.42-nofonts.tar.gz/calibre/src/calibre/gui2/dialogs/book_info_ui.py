# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/dialogs/book_info.ui'
#
# Created: Wed Jan 13 15:07:13 2010
#      by: PyQt4 UI code generator 4.6.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_BookInfo(object):
    def setupUi(self, BookInfo):
        BookInfo.setObjectName("BookInfo")
        BookInfo.resize(917, 783)
        self.gridLayout = QtGui.QGridLayout(BookInfo)
        self.gridLayout.setObjectName("gridLayout")
        self.title = QtGui.QLabel(BookInfo)
        self.title.setAlignment(QtCore.Qt.AlignCenter)
        self.title.setObjectName("title")
        self.gridLayout.addWidget(self.title, 0, 0, 1, 2)
        self.cover = QtGui.QGraphicsView(BookInfo)
        self.cover.setObjectName("cover")
        self.gridLayout.addWidget(self.cover, 1, 0, 1, 1)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.text = QtGui.QLabel(BookInfo)
        self.text.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.text.setWordWrap(True)
        self.text.setObjectName("text")
        self.verticalLayout.addWidget(self.text)
        self.groupBox = QtGui.QGroupBox(BookInfo)
        self.groupBox.setObjectName("groupBox")
        self.gridlayout = QtGui.QGridLayout(self.groupBox)
        self.gridlayout.setObjectName("gridlayout")
        self.comments = QtGui.QTextBrowser(self.groupBox)
        self.comments.setObjectName("comments")
        self.gridlayout.addWidget(self.comments, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.groupBox)
        self.fit_cover = QtGui.QCheckBox(BookInfo)
        self.fit_cover.setObjectName("fit_cover")
        self.verticalLayout.addWidget(self.fit_cover)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.previous_button = QtGui.QPushButton(BookInfo)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("previous.svg")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.previous_button.setIcon(icon)
        self.previous_button.setObjectName("previous_button")
        self.horizontalLayout.addWidget(self.previous_button)
        self.next_button = QtGui.QPushButton(BookInfo)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(I("next.svg")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.next_button.setIcon(icon1)
        self.next_button.setObjectName("next_button")
        self.horizontalLayout.addWidget(self.next_button)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.gridLayout.addLayout(self.verticalLayout, 1, 1, 1, 1)

        self.retranslateUi(BookInfo)
        QtCore.QMetaObject.connectSlotsByName(BookInfo)

    def retranslateUi(self, BookInfo):
        BookInfo.setWindowTitle(_("Dialog"))
        self.title.setText(_("TextLabel"))
        self.text.setText(_("TextLabel"))
        self.groupBox.setTitle(_("Comments"))
        self.fit_cover.setText(_("Fit &cover to view"))
        self.previous_button.setText(_("&Previous"))
        self.next_button.setText(_("&Next"))


