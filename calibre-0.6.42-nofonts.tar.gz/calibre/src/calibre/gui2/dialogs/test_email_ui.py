# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/dialogs/test_email.ui'
#
# Created: Fri Sep 25 13:36:50 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(542, 418)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("config.svg")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Dialog.setWindowIcon(icon)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.from_ = QtGui.QLabel(Dialog)
        self.from_.setWordWrap(True)
        self.from_.setObjectName("from_")
        self.verticalLayout.addWidget(self.from_)
        self.to = QtGui.QLineEdit(Dialog)
        self.to.setObjectName("to")
        self.verticalLayout.addWidget(self.to)
        self.label = QtGui.QLabel(Dialog)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.test_button = QtGui.QPushButton(Dialog)
        self.test_button.setObjectName("test_button")
        self.verticalLayout.addWidget(self.test_button)
        self.log = QtGui.QPlainTextEdit(Dialog)
        self.log.setObjectName("log")
        self.verticalLayout.addWidget(self.log)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("accepted()"), Dialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("rejected()"), Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_("Test email settings"))
        self.from_.setText(_("Send test mail from %s to:"))
        self.test_button.setText(_("&Test"))


