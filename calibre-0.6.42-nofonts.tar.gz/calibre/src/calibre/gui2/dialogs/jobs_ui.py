# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/dialogs/jobs.ui'
#
# Created: Fri Sep 25 13:36:51 2009
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_JobsDialog(object):
    def setupUi(self, JobsDialog):
        JobsDialog.setObjectName("JobsDialog")
        JobsDialog.resize(633, 542)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("jobs.svg")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        JobsDialog.setWindowIcon(icon)
        self.vboxlayout = QtGui.QVBoxLayout(JobsDialog)
        self.vboxlayout.setObjectName("vboxlayout")
        self.jobs_view = JobsView(JobsDialog)
        self.jobs_view.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.jobs_view.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.jobs_view.setAlternatingRowColors(True)
        self.jobs_view.setSelectionMode(QtGui.QAbstractItemView.SingleSelection)
        self.jobs_view.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.jobs_view.setIconSize(QtCore.QSize(32, 32))
        self.jobs_view.setObjectName("jobs_view")
        self.vboxlayout.addWidget(self.jobs_view)
        self.kill_button = QtGui.QPushButton(JobsDialog)
        self.kill_button.setObjectName("kill_button")
        self.vboxlayout.addWidget(self.kill_button)
        self.details_button = QtGui.QPushButton(JobsDialog)
        self.details_button.setObjectName("details_button")
        self.vboxlayout.addWidget(self.details_button)
        self.stop_all_jobs_button = QtGui.QPushButton(JobsDialog)
        self.stop_all_jobs_button.setObjectName("stop_all_jobs_button")
        self.vboxlayout.addWidget(self.stop_all_jobs_button)

        self.retranslateUi(JobsDialog)
        QtCore.QMetaObject.connectSlotsByName(JobsDialog)

    def retranslateUi(self, JobsDialog):
        JobsDialog.setWindowTitle(_("Active Jobs"))
        self.kill_button.setText(_("&Stop selected job"))
        self.details_button.setText(_("Show job &details"))
        self.stop_all_jobs_button.setText(_("Stop &all jobs"))

from calibre.gui2.widgets import JobsView

