# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kovid/work/calibre/src/calibre/gui2/catalog/catalog_epub_mobi.ui'
#
# Created: Mon Feb  8 22:00:25 2010
#      by: PyQt4 UI code generator 4.7
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(579, 411)
        self.gridLayout = QtGui.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.label_2 = QtGui.QLabel(Form)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.exclude_tags = QtGui.QLineEdit(Form)
        self.exclude_tags.setObjectName("exclude_tags")
        self.gridLayout.addWidget(self.exclude_tags, 0, 1, 1, 1)
        self.label_3 = QtGui.QLabel(Form)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 1)
        self.read_tag = QtGui.QLineEdit(Form)
        self.read_tag.setObjectName("read_tag")
        self.gridLayout.addWidget(self.read_tag, 1, 1, 1, 1)
        self.label_4 = QtGui.QLabel(Form)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 2, 0, 1, 1)
        self.note_tag = QtGui.QLineEdit(Form)
        self.note_tag.setObjectName("note_tag")
        self.gridLayout.addWidget(self.note_tag, 2, 1, 1, 1)
        self.exclude_genre = QtGui.QLineEdit(Form)
        self.exclude_genre.setObjectName("exclude_genre")
        self.gridLayout.addWidget(self.exclude_genre, 4, 1, 1, 1)
        self.label = QtGui.QLabel(Form)
        self.label.setTextFormat(QtCore.Qt.LogText)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 4, 0, 1, 1)
        self.label_6 = QtGui.QLabel(Form)
        self.label_6.setWordWrap(True)
        self.label_6.setObjectName("label_6")
        self.gridLayout.addWidget(self.label_6, 5, 1, 1, 1)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 6, 0, 1, 1)
        self.generate_titles = QtGui.QCheckBox(Form)
        self.generate_titles.setObjectName("generate_titles")
        self.gridLayout.addWidget(self.generate_titles, 8, 0, 1, 1)
        self.generate_recently_added = QtGui.QCheckBox(Form)
        self.generate_recently_added.setObjectName("generate_recently_added")
        self.gridLayout.addWidget(self.generate_recently_added, 9, 0, 1, 1)
        self.numbers_as_text = QtGui.QCheckBox(Form)
        self.numbers_as_text.setObjectName("numbers_as_text")
        self.gridLayout.addWidget(self.numbers_as_text, 10, 0, 1, 1)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_("Form"))
        self.label_2.setText(_("\'Don\'t include this book\' tag:"))
        self.label_3.setText(_("\'Mark this book as read\' tag:"))
        self.label_4.setText(_("Additional note tag prefix:"))
        self.label.setText(_("Regex pattern describing tags to exclude as genres:"))
        self.label_6.setText(_("Regex tips:\n"
"- The default regex - \\[[\\w ]*\\] - excludes genre tags of the form [tag], e.g., [Amazon Freebie]\n"
"- A regex pattern of a single dot excludes all genre tags, generating no Genre Section"))
        self.generate_titles.setText(_("Include \'Titles\' Section"))
        self.generate_recently_added.setText(_("Include \'Recently Added\' Section"))
        self.numbers_as_text.setText(_("Sort numbers as text"))

